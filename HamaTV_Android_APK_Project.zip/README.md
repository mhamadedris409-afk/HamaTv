# Hama TV Android
APK-ready Android Studio project.

Included:
- Rudaw
- New Line 1
- New Line 2 placeholder
- Search
- Media3/ExoPlayer playback for HLS/DASH/compatible streams
- Quality button placeholder; real quality choices depend on the stream's available variants.

Important:
The stream URLs included here are public URLs found online and are not guaranteed to be official, active, or permitted for redistribution. Replace them with official/licensed stream URLs before publishing.
Build: Android Studio -> Open project -> Build -> Generate App Bundle/APK.

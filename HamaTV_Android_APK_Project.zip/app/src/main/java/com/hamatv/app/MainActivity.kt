package com.hamatv.app

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.google.android.material.button.MaterialButton
import android.text.Editable
import android.text.TextWatcher

data class Channel(val ku:String,val ar:String,val en:String,val url:String)

class MainActivity: AppCompatActivity(){
 private lateinit var playerView:PlayerView
 private lateinit var player:ExoPlayer
 private lateinit var adapter:ChannelAdapter
 private lateinit var status:TextView
 private val channels=listOf(
   Channel("ڕووداو","روداو","Rudaw","https://svs.itworkscdn.net/rudawlive/rudawlive.smil/playlist.m3u8"),
   Channel("New Line 1","New Line 1","New Line 1","http://62.210.87.152/live/Safin_Rmrwwr/U3w9wDUv/1958.ts"),
   Channel("New Line 2","New Line 2","New Line 2","")
 )
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main)
  playerView=findViewById(R.id.player); status=findViewById(R.id.status)
  player=ExoPlayer.Builder(this).build(); playerView.player=player
  adapter=ChannelAdapter(channels){play(it)}
  findViewById<RecyclerView>(R.id.list).layoutManager=LinearLayoutManager(this)
  findViewById<RecyclerView>(R.id.list).adapter=adapter
  findViewById<EditText>(R.id.search).addTextChangedListener(object:TextWatcher{
   override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){}
   override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){adapter.filter(s.toString())}
   override fun afterTextChanged(e:Editable?){}
  })
  findViewById<MaterialButton>(R.id.quality).setOnClickListener{
   Toast.makeText(this,"Quality: Auto / 1080p / 720p / 480p (only if the stream provides them)",Toast.LENGTH_LONG).show()
  }
 }
 private fun play(c:Channel){
  if(c.url.isBlank()){status.text="ئەم کەناڵە هێشتا لینکی Live ـی نییە.";playerView.visibility=android.view.View.GONE;return}
  playerView.visibility=android.view.View.VISIBLE;status.text=""
  val item=MediaItem.Builder().setUri(c.url).build()
  player.setMediaItem(item);player.prepare();player.playWhenReady=true
 }
 override fun onDestroy(){player.release();super.onDestroy()}
}

class ChannelAdapter(private val original:List<Channel>,private val click:(Channel)->Unit):RecyclerView.Adapter<ChannelAdapter.VH>(){
 private var shown=original.toList()
 class VH(val t:TextView):RecyclerView.ViewHolder(t)
 override fun onCreateViewHolder(p:android.view.ViewGroup,v:Int):VH{
  val t=TextView(p.context);t.setTextColor(android.graphics.Color.WHITE);t.textSize=18f;t.setPadding(22,25,22,25)
  t.setBackgroundColor(android.graphics.Color.rgb(18,26,48));return VH(t)
 }
 override fun onBindViewHolder(h:VH,pos:Int){val c=shown[pos];h.t.text="📺  ${c.ku}\n    ${c.en}";h.t.setOnClickListener{click(c)}}
 override fun getItemCount()=shown.size
 fun filter(q:String){val x=q.trim().lowercase();shown=if(x.isEmpty()) original.toList() else original.filter{(it.ku+" "+it.ar+" "+it.en).lowercase().contains(x)};notifyDataSetChanged()}
}